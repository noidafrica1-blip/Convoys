@echo off
cd /d "%~dp0"
py -3.11 -m venv .venv
call .venv\Scripts\activate.bat
py -m pip install --upgrade pip
py -m pip install -r requirements.txt
py -m streamlit run convoy_monitor.py
pause
