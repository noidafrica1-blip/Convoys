# CONVOY MONITOR — Multi-user Streamlit build

## Start on Windows
1. Install Python 3.11 or newer.
2. Extract this ZIP.
3. Double-click `START_HERE_WINDOWS.bat`, or run in PowerShell:

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
py -m pip install --upgrade pip
py -m pip install -r requirements.txt
py -m streamlit run convoy_monitor.py
```

Streamlit opens in your browser, usually at `http://localhost:8501`.

## First launch and multiple logins
- On first launch, create the first Administrator account.
- Sign in as Administrator.
- Open **User account management** in the sidebar to create individual staff logins.
- **Controller** can operate convoy controls; **Viewer** has read-only access.
- Staff should use individual accounts, not shared credentials.
- Passwords are stored as salted PBKDF2-SHA256 hashes, not plain text.

## Shared access
Run one Streamlit instance on an always-on office PC/server. Staff on the same private network can open `http://SERVER-IP:8501` from their phones or computers. Allow port 8501 on the private network firewall. For remote access, use a VPN or HTTPS reverse proxy; do not expose the raw Streamlit port directly to the public internet.

## Data and limitations
SQLite stores user accounts, convoy assignments, GPS history, geofences and checkpoint events in `convoy_monitor.db`. Keep the database on the server's local disk. For larger deployments or multiple app servers, use PostgreSQL.

This version supports GPS CSV uploads. Live GPS vendor integration still requires the provider's API documentation and credentials. Configure verified geofence coordinates before relying on automatic checkpoint events. `sample_gps_upload.csv` is a template; change its convoy IDs and registrations to match your test convoy.
